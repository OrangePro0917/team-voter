import firebase from 'firebase';

  var firebaseConfig = {
    //paste your SDK here
   
  apiKey: "AIzaSyCrXWybuYaOmsHiFlmug7cAtQ5cvdwS9YI",
  authDomain: "team-voter-2d73b.firebaseapp.com",
  projectId: "team-voter-2d73b",
  storageBucket: "team-voter-2d73b.appspot.com",
  messagingSenderId: "890817677496",
  appId: "1:890817677496:web:56de7c05699ecafd794c4d"
};

// Initialize Firebase


  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  
  export default firebase.database();